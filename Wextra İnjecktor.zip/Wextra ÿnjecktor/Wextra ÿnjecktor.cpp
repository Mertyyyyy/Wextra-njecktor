﻿#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <vector>
#include <string>
#include <commdlg.h>

#ifndef FOREGROUND_YELLOW
#define FOREGROUND_YELLOW (FOREGROUND_RED | FOREGROUND_GREEN)
#endif

#ifndef FOREGROUND_CYAN
#define FOREGROUND_CYAN (FOREGROUND_GREEN | FOREGROUND_BLUE)
#endif

struct ProcessInfo {
    DWORD pid;
    std::wstring name;
};

std::vector<ProcessInfo> ListProcesses() {
    std::vector<ProcessInfo> processes;

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) {
        std::wcerr << L"Snapshot alinamadi.\n";
        return processes;
    }

    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);

    if (!Process32FirstW(hSnap, &pe)) {
        std::wcerr << L"Process32First basarisiz.\n";
        CloseHandle(hSnap);
        return processes;
    }

    do {
        processes.push_back({ pe.th32ProcessID, pe.szExeFile });
    } while (Process32NextW(hSnap, &pe));

    CloseHandle(hSnap);
    return processes;
}

std::wstring OpenFileDialog() {
    OPENFILENAMEW ofn;
    wchar_t szFile[MAX_PATH] = L"";

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"DLL Files (*.dll)\0*.dll\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

    if (GetOpenFileNameW(&ofn)) {
        return szFile;
    }
    return L"";
}

bool InjectDLL(DWORD pid, const std::wstring& dllPath) {
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProcess) {
        std::wcerr << L"OpenProcess failed. Error: " << GetLastError() << L"\n";
        return false;
    }

    int len = WideCharToMultiByte(CP_ACP, 0, dllPath.c_str(), -1, NULL, 0, NULL, NULL);
    std::string dllPathAnsi(len, 0);
    WideCharToMultiByte(CP_ACP, 0, dllPath.c_str(), -1, &dllPathAnsi[0], len, NULL, NULL);

    void* pLibRemote = VirtualAllocEx(hProcess, NULL, dllPathAnsi.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pLibRemote) {
        std::wcerr << L"VirtualAllocEx failed. Error: " << GetLastError() << L"\n";
        CloseHandle(hProcess);
        return false;
    }

    if (!WriteProcessMemory(hProcess, pLibRemote, dllPathAnsi.c_str(), dllPathAnsi.size(), NULL)) {
        std::wcerr << L"WriteProcessMemory failed. Error: " << GetLastError() << L"\n";
        VirtualFreeEx(hProcess, pLibRemote, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    LPVOID pLoadLibrary = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    if (!pLoadLibrary) {
        std::wcerr << L"GetProcAddress failed. Error: " << GetLastError() << L"\n";
        VirtualFreeEx(hProcess, pLibRemote, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0,
        (LPTHREAD_START_ROUTINE)pLoadLibrary,
        pLibRemote, 0, NULL);

    if (!hThread) {
        std::wcerr << L"CreateRemoteThread failed. Error: " << GetLastError() << L"\n";
        VirtualFreeEx(hProcess, pLibRemote, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    WaitForSingleObject(hThread, INFINITE);

    VirtualFreeEx(hProcess, pLibRemote, 0, MEM_RELEASE);
    CloseHandle(hThread);
    CloseHandle(hProcess);

    return true;
}

void SetConsoleColor(WORD color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void ShowMenu() {
    SetConsoleColor(FOREGROUND_CYAN | FOREGROUND_INTENSITY);
    std::wcout << L"======== Wextra Injektor ========\n\n";

    SetConsoleColor(FOREGROUND_YELLOW | FOREGROUND_INTENSITY);
    std::wcout << L"1. DLL Inject Et\n";
    std::wcout << L"2. Ayarlar\n";
    std::wcout << L"3. Cikis\n\n";

    SetConsoleColor(FOREGROUND_CYAN | FOREGROUND_INTENSITY);
    std::wcout << L"Seciminizi girin: ";
    SetConsoleColor(FOREGROUND_INTENSITY);
}

void ShowSettings() {
    system("cls");
    SetConsoleColor(FOREGROUND_CYAN | FOREGROUND_INTENSITY);
    std::wcout << L"======= Ayarlar =======\n\n";

    SetConsoleColor(FOREGROUND_YELLOW | FOREGROUND_INTENSITY);
    std::wcout << L"Mevcut inject sistemi LoadLibraryA olarak sabitlenmistir.\n";
    std::wcout << L"Degistirilemez.\n\n";

    SetConsoleColor(FOREGROUND_CYAN | FOREGROUND_INTENSITY);
    std::wcout << L"Discord destek kanali: https://discord.gg/gbBWRPRzt2\n\n";

    SetConsoleColor(FOREGROUND_INTENSITY);
    std::wcout << L"Devam etmek icin herhangi bir tusa basin...";
    std::wcin.ignore();
    std::wcin.get();
    system("cls");
}

void InjectFlow() {
    system("cls");
    std::wcout << L"Calisan islemler listeleniyor...\n";

    auto processes = ListProcesses();

    if (processes.empty()) {
        std::wcout << L"Hic islem bulunamadi.\n";
        system("pause");
        system("cls");
        return;
    }

    for (size_t i = 0; i < processes.size(); ++i) {
        std::wcout << i + 1 << L". PID: " << processes[i].pid << L" - " << processes[i].name << L"\n";
    }

    std::wcout << L"\nBir islem secmek icin numarasini girin: ";
    int choice = 0;
    std::wcin >> choice;

    if (choice < 1 || (size_t)choice > processes.size()) {
        std::wcout << L"Gecersiz secim.\n";
        system("pause");
        system("cls");
        return;
    }

    DWORD pid = processes[choice - 1].pid;
    std::wcout << L"Secilen PID: " << pid << L" - " << processes[choice - 1].name << L"\n";

    std::wcout << L"DLL dosyasini secin (.dll dosyasi)\n";
    std::wstring dllPath = OpenFileDialog();
    if (dllPath.empty()) {
        std::wcout << L"DLL secilmedi.\n";
        system("pause");
        system("cls");
        return;
    }

    if (InjectDLL(pid, dllPath)) {
        SetConsoleColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        std::wcout << L"DLL basariyla inject edildi!\n";
    }
    else {
        SetConsoleColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
        std::wcout << L"DLL inject edilemedi!\n";
    }

    SetConsoleColor(FOREGROUND_INTENSITY);
    system("pause");
    system("cls");
}

int wmain() {
    SetConsoleTitleW(L"Wextra Injektor");

    while (true) {
        ShowMenu();

        int secim = 0;
        std::wcin >> secim;

        switch (secim) {
        case 1:
            InjectFlow();
            break;
        case 2:
            ShowSettings();
            break;
        case 3:
            SetConsoleColor(FOREGROUND_CYAN | FOREGROUND_INTENSITY);
            std::wcout << L"Cikis yapiliyor...\n";
            return 0;
        default:
            SetConsoleColor(FOREGROUND_RED | FOREGROUND_INTENSITY);
            std::wcout << L"Gecersiz secim!\n";
            SetConsoleColor(FOREGROUND_INTENSITY);
            Sleep(1000);
            system("cls");
            break;
        }
    }
}

// Bu kod acik kaynak kodludur.
// Yapan: meryy_y
